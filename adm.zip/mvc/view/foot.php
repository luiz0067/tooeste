<?php //include 'template.php';?>
<?php foot();?>