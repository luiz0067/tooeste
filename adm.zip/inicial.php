<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="/adm/assets/css/estilocms.css" />
</head>

<body>
<a class="textoinicial">Você está logado com nível Administrador<br><br>

Nosso sistema iterativo esta cheio de novidades.<br><br> 

Para iniciar, solicitamos que atualize seus dados de usuário, pois nesta sessão existem inúmeros recursos que<br> 
são se suma importância para a funcionalidade do sistema.<br><br>

A INPROLINK INFORMÁTICA é uma empresa que está a mais de 10 anos no mercado oferecendo vário tipos de serviço e soluções em iformática.
<ul>
	<li>Designer gráfico 2D e 3D</li>
</ul>
<ul>
	<li>Web Design</li>
</ul>
<ul>
	<li>Assistêcia técnica</li>
</ul>
<ul>
	<li>Treinamentos</li>
</ul>
	<br>
	A técnologia aproxima pessoas e empresas.<br>
	Alem de ser a melhor ferramenta de otimização e automatização de negócios.<br>
	<br>
	Baseado nesse movimento desenvolmos soluções que link seus cliente de forma prática e rápida
	<br>
	<br>
	<br>
	INPROLINK ligando você a uma carreira de sucesso!<br>

	Caso precise de ajuda para usar o sistema, não exite em chamar o suporte.<br><br>

	Abraços a todos, espero que gostem do sistema.<br><br><br><br>

	INPROLINK INFORMÁTICA.</a><br>

</a>
</body>
</html>