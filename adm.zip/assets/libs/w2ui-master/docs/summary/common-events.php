<link rel="stylesheet" type="text/css" href="../summary.css"/> 
<div class="container"><div class="obj-property">
    <a href="common.onDestroy">onDestroy</a> <span>- function (event)</span>
</div>
<div class="obj-property-desc">
    Called when object is destroyed. 
</div>

<div class="obj-property">
    <a href="common.onRefresh">onRefresh</a> <span>- function (event)</span>
</div>
<div class="obj-property-desc">
    Called when object is refreshed. 
</div>

<div class="obj-property">
    <a href="common.onRender">onRender</a> <span>- function (event)</span>
</div>
<div class="obj-property-desc">
    Called when object is rendered. 
</div>

<div class="obj-property">
    <a href="common.onResize">onResize</a> <span>- function (event)</span>
</div>
<div class="obj-property-desc">
    Called when object is resized. 
</div>

</div>