<link rel="stylesheet" type="text/css" href="../summary.css"/> 
<div class="container"><div class="obj-property">
    <a href="w2toolbar.onClick">onClick</a> <span>- function (event)</span>
</div>
<div class="obj-property-desc">
    Called when toolbar item is clicked.
</div>

</div>