<link rel="stylesheet" type="text/css" href="../summary.css"/> 
<div class="container"><div class="obj-property">
    <a href="w2tabs.onClick">onClick</a> <span>- function (event)</span>
</div>
<div class="obj-property-desc">
    Called when tab is clicked.
</div>

<div class="obj-property">
    <a href="w2tabs.onClose">onClose</a> <span>- function (event)</span>
</div>
<div class="obj-property-desc">
    Called when tab is closed.
</div>

</div>