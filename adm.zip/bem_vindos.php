<div id="" class="" style="height:850px;width:100%;z-index:1;position:absolute;background-color:#CCCCCC;margin: 0 0 0 0 px; paddding:0 0 0 0;">
     <div class="" style="clear:both;height:150px;width:100%;text-align:center;overflow:hidden;margin: 0 0 0 0 px; paddding:0 0 0 0;background-color:#FFFFFF;">
		
	</div>
    <div class="" style="clear:both;background-color:#FFFFFF;height:250px;width:100%;margin: 0px 0px 0px 0px; paddding:0px 0px 0px 0px;">

	</div> 
</div>



<div id="login" class="" style="background-repeat:no-repeat;background-image:url('/adm/assets/img/cms/LINK LINK.png');height:850px;width:100%;z-index:2;position:absolute;display:block">
	<div class="" style="clear:both;height:150px;width:100%;text-align:center;overflow:hidden;margin: 0 0 0 0 px; paddding:0 0 0 0;">
		<img src="/adm/assets/img/cms/inprolink.png" style="height:150px;margin-left:auto;margin-right:auto;">
	</div> 
    <div class="row" style="width:100%;">

		<div class="col-md-4" style="margin-left:auto;margin-right:auto;width:320px;">
			<form class="form-login" method="POST">
				
				<h2 class="form-login-heading" style="background-color:#FFFFFF;color:blue;text-align:center;">SEJA BEM VINDO</h2>
				<h3 class="form-login-heading" style="background-color:#FFFFFF;color:blue;text-align:center;">AO CMS LINK SYSTEM</h3>
				

				<div class="form-group">
					<div class="input-group ">
						<a class="btn btn-lg btn-primary btn-block" href="/adm/login.php"><input name="acao" class="btn btn-lg btn-primary btn-block" type="button	" value="Entrar"></a>							
					</div>
				</div>
				
			</form>
		</div> 
	</div> 
</div>
