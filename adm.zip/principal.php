<?php include 'mvc/view/top.php'?>
<?php include './verifica.php'?>
<div id="tudo">
<div class="linhastotal" style="background-color:#000;">
  <div id="barrasair">
    <div id="sair">
      <div id="botaooff"><img src="/adm/assets/img/cms/off.gif" width="26" height="30" border="0" /></div>
      <div id="divtextosair"><a class="textosair" href="./logout.php">SAIR</a></div>
    </div>
    <div class="branco" style="width:750px; height:30px;"></div>
    <div id="encerramento">SESSÃO ENCERRA EM:&nbsp;<a id="cronometro"></a></div>
  </div>
</div>
<div class="linhastotal" style="background-color:#E8E8E8;">
  <div class="linhascentro">
    <div id="barrabanner">
      <div id="containercrm">
        <div id="crminprolink"><img src="/adm/assets/img/cms/cmsinprolink.jpg"  width="210" height="84" border="0"/></div>
      </div>
      <div id="containercliente">
        <div id="fotocliente"><img src="/adm/assets/img/cms/LINK_LINK_4.jpg" width="auto" height="120" border="0"></div>
      </div>
      <div class="branco" style="height:140px; width:300px;"></div>
      <div id="riscobarra"></div>
      <div id="containerjava">
        <div class="branco" style="width:197px; height:76px; margin-top:14px; display:inline;">
          <div class="branco" style="height:71px; width:80px; font-family:Verdana, Geneva, sans-serif; font-size:14px; padding-top:5px; color:#666666;">Tecnologia</div>
		  <div class="branco" style="margin-top:25px;"> <img src="/adm/assets/img/cms/php.png" width="80" height="50" border="0"></div>
          <div id="logojava"></div>
        </div>
        <div class="branco" style="width:197px; height:50px;">
          <div id="logomix"></div>
          <div class="branco" style="width:153px; height:50px; display:block; overflow:hidden; font-family:Verdana, Geneva, sans-serif; font-size:08px; color:#666666;">Developed by<br>
            <a style="font-size:10px;">INPROLINK INFORMÁTICA</a><br>
            Todos os direitos reservados&copy;</div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="linhastotal" style="background-image:url(/adm/assets/img/cms/risco1.gif); background-repeat:repeat-x;">
  <div class="linhascentro">
    <div id="risco1"></div>
  </div>
</div>
<div class="linhastotal">
  <div class="linhascentro">
    <div id="barrausuario">
      <div id="bemvindo">Bem - Vindo,

      </div>
      <div class="branco" style="width:511px; height:45px; float:left;"></div>
      <div id="ferramentas">
        <div id="trocarsenha"><a href="./trocar_senha.php" target="conteudomeio" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','/adm/assets/img/cms/senha1.gif',1)"><img src="/adm/assets/img/cms/senha2.gif" alt="Trocar Senha" name="Image2" width="124" height="45" border="0" id="Image2" /></a></div>
        <div id="suporte"><a href="suporte.php" target="conteudomeio" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','/adm/assets/img/cms/suporte1.gif',1)"><img src="/adm/assets/img/cms/suporte2.gif" alt="Suporte" name="Image3" width="114" height="45" border="0" id="Image3" /></a></div>
      </div>
    </div>
  </div>
</div>
<div class="linhastotal" style="background-image:url(/adm/assets/img/cms/risco1.gif); background-repeat:repeat-x;">
  <div class="linhascentro">
    <div id="risco1"></div>
  </div>
</div>

<div class="linhastotal" style="background-image:url(/adm/assets/img/cms/risco1.gif); background-repeat:repeat-x;">
  <div class="linhascentro">
    <div id="risco1"></div>
  </div>
</div>
<body>
</body>
</html>
<div class="linhastotal">
<div id="conteudocentro">
<div class="menuprincipal">


<body>
<div id="menuscontainer">

	<div id="menudecomando">CADASTROS</div>
    <div class="branco" style="width:257px; height:28px;"></div>
        <ul id="menulateral">
            <li>
            <a href="./mvc/view/cadastro_menus.php" target="conteudomeio">
				Menus
			</a>
            </li>
		</ul>
		<div class="branco" style="width:257px; height:28px;"></div>
        <ul id="menulateral">
            <li>
            <a href="./mvc/view/cadastro_album_fotos.php" target="conteudomeio">
				Album Fotos
			</a>
            </li>
		</ul>		
		<div class="branco" style="width:257px; height:28px;"></div>
		<ul id="menulateral">
            <li>
            <a href="./mvc/view/cadastro_fotos.php" target="conteudomeio">
				Fotos 
			</a>
            </li>
		</ul>
		
				<div class="branco" style="width:257px; height:28px;"></div>
        <ul id="menulateral">
            <li>
            <a href="./mvc/view/cadastro_album_videos.php" target="conteudomeio">
				Album Vídeos
			</a>
            </li>
		</ul>		
		<div class="branco" style="width:257px; height:28px;"></div>
		<ul id="menulateral">
            <li>
            <a href="./mvc/view/cadastro_videos.php" target="conteudomeio">
				Vídeos 
			</a>
            </li>
		</ul>
		
		
		
		<div class="branco" style="width:257px; height:28px;"></div>
	    <ul id="menulateral">
            <li>
            <a href="./mvc/view/cadastro_noticias.php" target="conteudomeio">
				Notícias
			</a>
            </li>
             <li>
            <a href="./mvc/view/cadastro_noticias_fotos.php" target="conteudomeio">
				Notícias Fotos
			</a>
            </li>
            <li>
            <a href="./mvc/view/cadastro_noticias_anexo.php" target="conteudomeio">
				Notícias anexo
			</a>
            </li>
            
            
            
		</ul>
		<div class="branco" style="width:257px; height:28px;"></div>
        <ul id="menulateral">
            <li>
            <a href="./mvc/view/cadastro_usuarios.php" target="conteudomeio">
				Usuários
			</a>
            </li>
		</ul>		
</div>


</div>
<div id="divisorconteudovertical"></div>
<div id="conteudoprincipal">
  <iframe name="conteudomeio" width="730" height="700" vspace="0" hspace="0" scrolling="auto" frameborder="0" src="inicial.php"></iframe>
</div>
</div>
</div>
<?php include 'mvc/view/foot.php'?>
